from unittest.mock import patch

from agents.executor import executor_node


REQUEST = {
    "tool_name": "calculate_metrics",
    "params": {
        "metric": "attack_success_rate",
        "records": [{"attack_success": True}],
    },
}


def test_executor_calls_action_gate_before_running_valid_tool_on(monkeypatch):
    monkeypatch.setenv("DEFENSE_MODE", "on")
    with patch(
        "agents.executor._execute_tool_isolated",
        return_value={"metric": "attack_success_rate", "value": 1.0},
    ) as execute:
        state = executor_node(
            {
                "user_query": "Calculate the attack success rate metric.",
                "execution_request": REQUEST,
                "execution_params_source": "planner",
            }
        )

    execute.assert_called_once()
    assert state["execution_result"]["status"] == "success"
    assert any(
        event["rule"] == "action_gate_context" and event["action"] == "allowed"
        for event in state["security_events"]
    )


def test_executor_blocks_retrieved_params_before_tool_execution_on(monkeypatch):
    monkeypatch.setenv("DEFENSE_MODE", "on")
    with patch("agents.executor._execute_tool_isolated") as execute:
        state = executor_node(
            {
                "user_query": "Calculate the attack success rate metric.",
                "execution_request": REQUEST,
                "execution_params_source": "retrieved_content",
            }
        )

    execute.assert_not_called()
    assert state["execution_result"]["status"] == "denied"
    assert state["security_events"][-1]["action"] == "blocked"
    assert "params_from_retrieved_content" in state["security_events"][-1]["detail"]


def test_executor_off_observes_mismatch_and_still_runs_allowlisted_tool(monkeypatch):
    monkeypatch.setenv("DEFENSE_MODE", "off")
    with patch(
        "agents.executor._execute_tool_isolated",
        return_value={"metric": "attack_success_rate", "value": 1.0},
    ) as execute:
        state = executor_node(
            {
                "user_query": "Explain least privilege.",
                "execution_request": REQUEST,
                "execution_params_source": "retrieved_content",
            }
        )

    execute.assert_called_once()
    assert state["execution_result"]["status"] == "success"
    assert any(event["action"] == "observed" for event in state["security_events"])

